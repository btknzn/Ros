
"use strict";

let CharacterCount = require('./CharacterCount.js')

module.exports = {
  CharacterCount: CharacterCount,
};
