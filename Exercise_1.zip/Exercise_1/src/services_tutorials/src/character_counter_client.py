from beg_tutorials.srv import *
import rospy
import sys

def handle_find_lenght(req):
	rospy.wait_for_service('character_cout')
	try :
		find_lenght = rospy.ServiceProxy('character_cout',CharacterCount)
		size = find_lenght(req)
		return size
		
	except rospy.ServiceException, e:
		print "Service call failed: %s"%e


if __name__ == "__main__":
	s = "batu"
	k = "kaan"
	o = "ozen"
	print("%s == %d",s,handle_find_lenght(s))
	print("%k == %d",k,handle_find_lenght(s))
	print("%o == %d",o,handle_find_lenght(s))
