from beg_tutorials.srv import *
import rospy

def handle_find_lenght(words):
	counter = len(words)
	return counter
	
def find_lenght_server():
	rospy.init_node('character_cout')
	s = rospy.Service('character_cout',CharacterCount,handle_find_lenght)
	rospy.spin()
	
if __name__ =="__main__":
	find_lenght_server()
